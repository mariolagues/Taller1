package Taller_1;
//Nombre: Mario Lagues, rut: 21974580-K, Carrera: ICCI 

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class App {

    public static void main(String[] args) throws FileNotFoundException {

        String[] datosExperimentos = leerArchivo("experimentos.txt", 10);
        String[] datosMetricas = leerArchivo("metricas.txt", 10);
        String[] datosPredicciones = leerArchivo("predicciones.txt", 200);

        if (datosExperimentos == null || datosMetricas == null || datosPredicciones == null) {
            System.out.println("Hubo un error al cargar alguno de los archivos. Terminando el programa...");
            return;
        }

        Scanner entrada = new Scanner(System.in);
        int eleccion;

        // Menú principal permite elegir entre Administrador, Usuario o Salir
        do {
            System.out.println("\n========= SISTEMA DE EVALUACION DE MODELOS =========");
            System.out.println("1. Menú para Administrador");
            System.out.println("2. Menú para Usuario");
            System.out.println("3. Salir");
            System.out.print("Elija una opción: ");
            eleccion = entrada.nextInt();

            switch (eleccion) {
                case 1:
                    menuAdmin(datosExperimentos, datosPredicciones);
                    break;
                case 2:
                    menuUsuario(datosExperimentos, datosPredicciones);
                    break;
                case 3:
                    System.out.println("Saliendo del sistema. Hasta luego.");
                    break;
                default:
                    System.out.println("Opción no válida, intente nuevamente.");
            }
        } while (eleccion != 3);

        entrada.close();
    }

    //  Menú con opciones avanzadas para el administrador
    public static void menuAdmin(String[] experimentos, String[] predicciones) {
        Scanner sc = new Scanner(System.in);
        int opcion;
        do {
            System.out.println("\n------ MENU ADMINISTRADOR ------");
            System.out.println("1. Mostrar tabla de métricas por experimento");
            System.out.println("2. Ver mejor F1-Score");
            System.out.println("3. Promedios generales de métricas");
            System.out.println("4. Comparar dos experimentos");
            System.out.println("5. Volver al menú principal");
            System.out.print("Ingrese opción: ");
            opcion = sc.nextInt();


            if (opcion == 1) {
                for (String linea : experimentos) {
                    if (linea != null) {
                        String[] partes = linea.split(";");
                        String nombreExp = partes[0];
                        int[] matriz = obtenerMatriz(nombreExp, predicciones);
                        double acc = calcularAccuracy(matriz);
                        double pre = calcularPrecision(matriz);
                        double rec = calcularRecall(matriz);
                        double f1 = calcularF1(pre, rec);
                        System.out.println(nombreExp + " -> Acc: " + red(acc) + " Prec: " + red(pre) + " Rec: " + red(rec) + " F1: " + red(f1));
                    }
                }
            }

            else if (opcion == 2) {
                String mejorId = "";
                double mejorF1 = -1;
                for (String linea : experimentos) {
                    if (linea != null) {
                        String[] partes = linea.split(";");
                        String id = partes[0];
                        int[] m = obtenerMatriz(id, predicciones);
                        double f1 = calcularF1(calcularPrecision(m), calcularRecall(m));
                        if (f1 > mejorF1) {
                            mejorF1 = f1;
                            mejorId = id;
                        }
                    }
                }
                System.out.println("Mejor F1-Score: " + red(mejorF1) + " correspondiente al experimento: " + mejorId);
            }

            else if (opcion == 3) {
                double sumaAcc = 0, sumaPre = 0, sumaRec = 0, sumaF1 = 0;
                int cant = 0;
                for (String linea : experimentos) {
                    if (linea != null) {
                        String[] partes = linea.split(";");
                        String id = partes[0];
                        int[] m = obtenerMatriz(id, predicciones);
                        double acc = calcularAccuracy(m);
                        double pre = calcularPrecision(m);
                        double rec = calcularRecall(m);
                        double f1 = calcularF1(pre, rec);
                        sumaAcc += acc;
                        sumaPre += pre;
                        sumaRec += rec;
                        sumaF1 += f1;
                        cant++;
                    }
                }
                System.out.println("Promedio Accuracy: " + red(sumaAcc / cant));
                System.out.println("Promedio Precision: " + red(sumaPre / cant));
                System.out.println("Promedio Recall: " + red(sumaRec / cant));
                System.out.println("Promedio F1: " + red(sumaF1 / cant));
            }

            else if (opcion == 4) {
                System.out.print("Ingrese ID del primer experimento: ");
                String id1 = sc.next();
                System.out.print("Ingrese ID del segundo experimento: ");
                String id2 = sc.next();
                int[] m1 = obtenerMatriz(id1, predicciones);
                int[] m2 = obtenerMatriz(id2, predicciones);
                System.out.println("Comparación " + id1 + " vs " + id2);
                System.out.println("Accuracy: " + red(calcularAccuracy(m1)) + " vs " + red(calcularAccuracy(m2)));
                System.out.println("Precision: " + red(calcularPrecision(m1)) + " vs " + red(calcularPrecision(m2)));
                System.out.println("Recall: " + red(calcularRecall(m1)) + " vs " + red(calcularRecall(m2)));
                System.out.println("F1: " + red(calcularF1(calcularPrecision(m1), calcularRecall(m1))) + " vs " + red(calcularF1(calcularPrecision(m2), calcularRecall(m2))));
            }
        } while (opcion != 5);
    }

    // Menú simplificado con funciones básicas para el usuario
    public static void menuUsuario(String[] experimentos, String[] predicciones) {
        Scanner sc = new Scanner(System.in);
        int op;
        do {
            System.out.println("\n------ MENU USUARIO ------");
            System.out.println("1. Ver nombres de experimentos disponibles");
            System.out.println("2. Ver matriz de confusión de un experimento");
            System.out.println("3. Ver métricas individuales de un experimento");
            System.out.println("4. Promedio de Accuracy");
            System.out.println("5. Volver al menú principal");
            System.out.print("Seleccione opción: ");
            op = sc.nextInt();

          
            if (op == 1) {
                for (String linea : experimentos) {
                    if (linea != null) {
                        String[] partes = linea.split(";");
                        System.out.println(partes[0]);
                    }
                }
            }
            
            else if (op == 2) {
                System.out.print("Ingrese ID del experimento: ");
                String id = sc.next();
                int[] m = obtenerMatriz(id, predicciones);
                System.out.println("VP: " + m[0] + " VN: " + m[1] + " FP: " + m[2] + " FN: " + m[3]);
            }

            else if (op == 3) {
                System.out.print("Ingrese ID del experimento: ");
                String id = sc.next();
                int[] m = obtenerMatriz(id, predicciones);
                System.out.println("Accuracy: " + red(calcularAccuracy(m)));
                System.out.println("Precision: " + red(calcularPrecision(m)));
                System.out.println("Recall: " + red(calcularRecall(m)));
                System.out.println("F1: " + red(calcularF1(calcularPrecision(m), calcularRecall(m))));
            }

            else if (op == 4) {
                double suma = 0;
                int c = 0;
                for (String linea : experimentos) {
                    if (linea != null) {
                        String[] partes = linea.split(";");
                        String id = partes[0];
                        suma += calcularAccuracy(obtenerMatriz(id, predicciones));
                        c++;
                    }
                }
                System.out.println("Promedio Accuracy: " + red(suma / c));
            }
        } while (op != 5);
    }

    // Lee un archivo de texto línea por línea
    public static String[] leerArchivo(String nombre, int limite) throws FileNotFoundException {
        File archivo = new File(nombre);
        Scanner lector = new Scanner(archivo);
        String[] datos = new String[limite];
        int i = 0;
        while (lector.hasNextLine() && i < limite) {
            datos[i] = lector.nextLine();
            i++;
        }
        lector.close();
        return datos;
    }

    // Genera la matriz de confusión de un experimento dado
    public static int[] obtenerMatriz(String id, String[] pred) {
        int vp = 0, vn = 0, fp = 0, fn = 0;
        for (String linea : pred) {
            if (linea != null && linea.startsWith(id)) {
                String[] partes = linea.split(";");
                int real = Integer.parseInt(partes[1]);
                int estimado = Integer.parseInt(partes[2]);
                if (real == 1 && estimado == 1){
                	vp++;
                }
                else if (real == 0 && estimado == 0){
                	vn++;
                }
                else if (real == 0 && estimado == 1){
                	fp++;
                }
                else if (real == 1 && estimado == 0) {
                	fn++;
                }
            }
        }
        return new int[]{vp, vn, fp, fn};
    }
    
    // Redondea un número a 3 decimales y lo devuelve como String
    public static String red(double numero) {
        int aux = (int)(numero * 1000 + 0.5);
        return (aux / 1000.0) + "";
    }

    // Calcula la exactitud del modelo
    public static double calcularAccuracy(int[] m) {
        int total = m[0] + m[1] + m[2] + m[3];
        return total == 0 ? 0 : (double)(m[0] + m[1]) / total;
    }

    // Calcula la precisión
    public static double calcularPrecision(int[] m) {
        return (m[0] + m[2]) == 0 ? 0 : (double)m[0] / (m[0] + m[2]);
    }

    // Calcula la sensibilidad
    public static double calcularRecall(int[] m) {
        return (m[0] + m[3]) == 0 ? 0 : (double)m[0] / (m[0] + m[3]);
    }

    // Calcula el F1-score
    public static double calcularF1(double p, double r) {
        return (p + r) == 0 ? 0 : 2 * p * r / (p + r);
    }

}
